import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, MinMaxScaler, LabelEncoder
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    classification_report, ConfusionMatrixDisplay,
    mean_absolute_error, mean_squared_error, r2_score
)
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.datasets import load_iris, load_breast_cancer, make_moons, make_circles

st.set_page_config(page_title="EduPulse | Student Analytics", page_icon="🎓", layout="wide")

st.markdown("""
<style>
.stApp {background:linear-gradient(180deg,#F5FAFF 0%,#FFFFFF 50%,#F6FBF4 100%);color:#263746}
.block-container {padding-top:1.25rem;max-width:1500px}
h1,h2,h3 {color:#1F4263}
div[data-testid="stMetric"] {background:#FFFFFF;border:1px solid #DCEAF5;padding:14px 16px;border-radius:16px;box-shadow:0 3px 10px #1c4a6a0a}
div.stButton>button {background:#1CB0F6;color:#082E49;border:0;border-radius:12px;font-weight:700}
div.stButton>button:hover {background:#1495D0;color:white}
[data-testid="stSidebar"] {background:#EEF7FF}
.hero {background:linear-gradient(115deg,#E0F2FF,#E9F9DF);padding:26px 30px;border:1px solid #D6E9F4;border-radius:22px;margin-bottom:18px}
.pill {display:inline-block;background:#DDF2FF;color:#155A85;border-radius:99px;padding:5px 10px;font-size:12px;font-weight:700;margin-right:5px}
</style>
""", unsafe_allow_html=True)

@st.cache_data
def make_student_data(n=1600, seed=17):
    rng=np.random.default_rng(seed)
    study=np.clip(rng.normal(2.7,1.1,n),0,8)
    attendance=np.clip(rng.normal(84,12,n),35,100)
    prior=np.clip(rng.normal(68,15,n),15,100)
    assignments=np.clip(rng.normal(78,16,n),10,100)
    sleep=np.clip(rng.normal(7,1.2,n),3,11)
    commute=np.clip(rng.gamma(2.1,12,n),1,100)
    support=rng.choice(["Low","Medium","High"],n,p=[.22,.53,.25])
    internet=rng.choice(["No","Yes"],n,p=[.16,.84])
    activities=rng.choice(["No","Yes"],n,p=[.42,.58])
    support_bonus=pd.Series(support).map({"Low":-4,"Medium":0,"High":4}).to_numpy()
    internet_bonus=pd.Series(internet).map({"No":-2,"Yes":1}).to_numpy()
    score=np.clip(19+study*4.4+(attendance-65)*.23+(prior-55)*.25+(assignments-60)*.13+
                  (sleep-6)*1.3+support_bonus+internet_bonus+rng.normal(0,7,n),0,100)
    risk=np.where((score<45)|(attendance<58),"High Risk",np.where((score<62)|(attendance<72),"Moderate Risk","Low Risk"))
    df=pd.DataFrame({
        "study_hours_daily":study.round(1),"attendance_pct":attendance.round(1),
        "previous_score":prior.round(1),"assignment_avg":assignments.round(1),
        "sleep_hours":sleep.round(1),"commute_minutes":commute.round(0),
        "family_support":support,"internet_access":internet,
        "extracurricular":activities,"final_score":score.round(1),"academic_risk":risk
    })
    for col in ["attendance_pct","assignment_avg","previous_score"]:
        df.loc[rng.choice(n,max(1,int(n*.015)),replace=False),col]=np.nan
    return df

students=make_student_data()
NUMERIC=["study_hours_daily","attendance_pct","previous_score","assignment_avg","sleep_hours","commute_minutes"]
TARGET_REG="final_score"
TARGET_CLF="academic_risk"

def clean_df(df):
    out=df.copy()
    for c in out.select_dtypes(include=np.number).columns:
        out[c]=out[c].fillna(out[c].median())
    for c in out.select_dtypes(exclude=np.number).columns:
        if out[c].isna().any(): out[c]=out[c].fillna(out[c].mode().iloc[0])
    return out

def show_fig(fig):
    st.pyplot(fig,use_container_width=True)
    plt.close(fig)

def metrics(items):
    cols=st.columns(len(items))
    for c,(label,val) in zip(cols,items): c.metric(label,val)

def get_clf_data(source):
    if source=="Student academic risk":
        df=clean_df(students)
        X=pd.get_dummies(df[NUMERIC+["family_support","internet_access","extracurricular"]],drop_first=True,dtype=int)
        y=LabelEncoder().fit_transform(df[TARGET_CLF])
        return X,pd.Series(y), "Student academic risk"
    if source=="Iris benchmark":
        ds=load_iris(as_frame=True)
        return ds.data,ds.target,"Iris benchmark"
    ds=load_breast_cancer(as_frame=True)
    return ds.data,ds.target,"Breast cancer benchmark"

def clf_pipeline(name,seed):
    estimator={
        "Logistic Regression":LogisticRegression(max_iter=2000),
        "Decision Tree":DecisionTreeClassifier(max_depth=5,random_state=seed),
        "K-Nearest Neighbors":KNeighborsClassifier(n_neighbors=7),
        "Gaussian Naive Bayes":GaussianNB(),
        "Random Forest":RandomForestClassifier(n_estimators=160,random_state=seed,class_weight="balanced"),
        "Linear SVM":SVC(kernel="linear"),
        "Polynomial SVM":SVC(kernel="poly",degree=3),
        "RBF SVM":SVC(kernel="rbf",gamma="scale")
    }[name]
    steps=[("imputer",SimpleImputer(strategy="median"))]
    if name in ["Logistic Regression","K-Nearest Neighbors","Linear SVM","Polynomial SVM","RBF SVM"]:
        steps.append(("scaler",StandardScaler()))
    steps.append(("model",estimator))
    return Pipeline(steps)

def compare_classifiers(X,y,seed,test_size,depth,n_trees):
    stratify=y if pd.Series(y).value_counts().min()>=2 else None
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=test_size,random_state=seed,stratify=stratify)
    models={
        "Decision Tree":Pipeline([("imputer",SimpleImputer(strategy="median")),("model",DecisionTreeClassifier(max_depth=depth,random_state=seed,class_weight="balanced"))]),
        "Random Forest":Pipeline([("imputer",SimpleImputer(strategy="median")),("model",RandomForestClassifier(n_estimators=n_trees,max_depth=depth,random_state=seed,class_weight="balanced"))])
    }
    scores=[]; fitted={}
    for name,m in models.items():
        m.fit(Xtr,ytr); p=m.predict(Xte); fitted[name]=m
        scores.append({"Model":name,"Accuracy":accuracy_score(yte,p),"Precision (weighted)":precision_score(yte,p,average="weighted",zero_division=0),"Recall (weighted)":recall_score(yte,p,average="weighted",zero_division=0),"F1 (weighted)":f1_score(yte,p,average="weighted",zero_division=0)})
    return Xtr,Xte,ytr,yte,fitted,pd.DataFrame(scores)

def compare_regressors(X,y,seed,test_size,depth,n_trees):
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=test_size,random_state=seed)
    models={
        "Decision Tree":Pipeline([("imputer",SimpleImputer(strategy="median")),("model",DecisionTreeRegressor(max_depth=depth,random_state=seed))]),
        "Random Forest":Pipeline([("imputer",SimpleImputer(strategy="median")),("model",RandomForestRegressor(n_estimators=n_trees,max_depth=depth,random_state=seed,n_jobs=-1))])
    }
    scores=[]; fitted={}; preds={}
    for name,m in models.items():
        m.fit(Xtr,ytr); p=m.predict(Xte); fitted[name]=m; preds[name]=p
        scores.append({"Model":name,"MAE":mean_absolute_error(yte,p),"MSE":mean_squared_error(yte,p),"RMSE":mean_squared_error(yte,p)**.5,"R²":r2_score(yte,p)})
    return Xtr,Xte,ytr,yte,fitted,preds,pd.DataFrame(scores)

st.sidebar.title("🎓 EduPulse")
st.sidebar.caption("Student Performance & Academic Risk")
pages=["Overview","01 · Data Explorer & EDA","02–03 · Score Regression","04–08 · Classification Lab","Normalization & Standardization","09–10 · SVM Kernel Lab","11 · Decision Tree vs Random Forest","Student Risk Playground","Dataset & Project Notes"]
page=st.sidebar.radio("Navigate",pages)
st.sidebar.markdown("---")
st.sidebar.caption("Educational prototype · Synthetic demo data")

if page=="Overview":
    st.markdown("""
    <div class="hero"><span class="pill">11 EXPERIMENT CONCEPTS</span><span class="pill">CLASSIFICATION + REGRESSION</span>
    <h1>🎓 EduPulse: Student Performance & Academic Risk Predictor</h1>
    <p>Explore learning patterns, estimate academic scores, and compare ML models through a friendly interactive dashboard.</p></div>
    """,unsafe_allow_html=True)
    metrics([("Sample records",f"{len(students):,}"),("Input features",len(NUMERIC)+3),("Risk categories",3),("Experiment modules",11)])
    st.subheader("Workflow")
    cols=st.columns(4)
    for c,title,desc in zip(cols,["Explore","Prepare","Train","Compare"],["Understand patterns and missing data","Impute, encode and scale inputs","Fit regression and classification models","Review metrics, plots and feature importance"]):
        with c: st.markdown(f"#### {title}"); st.write(desc)
    st.warning("The built-in dataset is synthetic. Risk predictions are demonstrations only and must not be used to label, penalize, or make high-stakes decisions about real students.")
    st.subheader("Experiment mapping")
    st.dataframe(pd.DataFrame([
        ["01","Pandas, Matplotlib, Seaborn, EDA","Data Explorer & EDA"],
        ["02","Simple Linear Regression","Score Regression"],
        ["03","Multiple Linear Regression","Score Regression"],
        ["04","Binary Logistic Regression","Classification Lab"],
        ["05","Multiclass Logistic Regression","Classification Lab"],
        ["06","Decision Tree","Classification Lab + Experiment 11"],
        ["07","KNN classifier","Classification Lab"],
        ["08","Naive Bayes classifier","Classification Lab"],
        ["Preprocessing","Normalization and standardization","Scaling module"],
        ["09","Linear SVM","SVM Kernel Lab"],
        ["10","Polynomial and RBF SVM","SVM Kernel Lab"],
        ["11","Decision Tree vs Random Forest: classification and regression","Dedicated comparison"],
    ],columns=["Experiment","Concept","Dashboard module"]),hide_index=True,use_container_width=True)

elif page=="01 · Data Explorer & EDA":
    st.title("01 · Data Explorer & EDA")
    uploaded=st.file_uploader("Optional: upload a student CSV",type=["csv"])
    df=students.copy() if uploaded is None else pd.read_csv(uploaded)
    st.caption("Default dataset: synthetic student records" if uploaded is None else f"Active dataset: {uploaded.name}")
    metrics([("Rows",f"{len(df):,}"),("Columns",len(df.columns)),("Missing cells",int(df.isna().sum().sum()))])
    st.dataframe(df.head(30),use_container_width=True)
    a,b=st.columns(2)
    with a:
        st.subheader("Missing values")
        miss=df.isna().sum().sort_values(ascending=False)
        fig,ax=plt.subplots(figsize=(8,4)); miss[miss>0].plot(kind="bar",ax=ax); ax.set_ylabel("Missing cells"); show_fig(fig)
    with b:
        nums=df.select_dtypes(include=np.number).columns.tolist()
        if nums:
            feature=st.selectbox("Distribution feature",nums)
            fig,ax=plt.subplots(figsize=(8,4)); sns.histplot(df[feature].dropna(),kde=True,ax=ax); show_fig(fig)
    st.subheader("Summary statistics")
    st.dataframe(df.describe(include="all").transpose(),use_container_width=True)
    nums_df=df.select_dtypes(include=np.number)
    if len(nums_df.columns)>1:
        fig,ax=plt.subplots(figsize=(10,6)); sns.heatmap(nums_df.corr(),annot=True,fmt=".2f",cmap="Blues",ax=ax); ax.set_title("Correlation heatmap"); show_fig(fig)
    cats=[c for c in df.select_dtypes(exclude=np.number).columns if df[c].nunique()<20]
    if cats and len(nums_df.columns):
        cat=st.selectbox("Group by category",cats); num=st.selectbox("Numeric measure",nums_df.columns.tolist(),key="eda_num")
        fig,ax=plt.subplots(figsize=(9,4)); sns.boxplot(data=df,x=cat,y=num,ax=ax); ax.tick_params(axis="x",rotation=20); show_fig(fig)
    st.download_button("Download dataset CSV",df.to_csv(index=False).encode(),"student_dataset.csv","text/csv")

elif page=="02–03 · Score Regression":
    st.title("02–03 · Score Regression")
    st.write("Compare simple linear regression using one feature with multiple linear regression using several features.")
    df=clean_df(students)
    one=st.selectbox("Feature for simple regression",NUMERIC)
    multiple=st.multiselect("Features for multiple regression",NUMERIC,default=["study_hours_daily","attendance_pct","previous_score","assignment_avg"])
    if not multiple: multiple=[one]
    test=st.slider("Test set size",.15,.4,.25,.05)
    seed=st.number_input("Random seed",0,9999,42)
    results=[]; fitted={}
    for name,features in [("Simple Linear Regression",[one]),("Multiple Linear Regression",multiple)]:
        X=df[features]; y=df[TARGET_REG]
        Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=test,random_state=int(seed))
        model=Pipeline([("imputer",SimpleImputer(strategy="median")),("model",LinearRegression())])
        model.fit(Xtr,ytr); pred=model.predict(Xte); fitted[name]=(Xte,yte,pred,features)
        results.append({"Model":name,"Features":len(features),"MAE":mean_absolute_error(yte,pred),"MSE":mean_squared_error(yte,pred),"RMSE":mean_squared_error(yte,pred)**.5,"R²":r2_score(yte,pred)})
    st.dataframe(pd.DataFrame(results).round(4),hide_index=True,use_container_width=True)
    choice=st.selectbox("Visualize model",list(fitted))
    Xte,yte,pred,features=fitted[choice]
    fig,ax=plt.subplots(figsize=(8,4)); ax.scatter(yte,pred,alpha=.65); lo=min(float(yte.min()),float(pred.min())); hi=max(float(yte.max()),float(pred.max())); ax.plot([lo,hi],[lo,hi],"--"); ax.set_xlabel("Actual score"); ax.set_ylabel("Predicted score"); ax.set_title(choice+" · Actual vs predicted"); show_fig(fig)

elif page=="04–08 · Classification Lab":
    st.title("04–08 · Classification Lab")
    source=st.selectbox("Dataset",["Student academic risk","Iris benchmark","Breast cancer benchmark"])
    X,y,_=get_clf_data(source)
    if source!="Student academic risk": st.info("This is a standard educational benchmark, included to demonstrate classification algorithms.")
    algo=st.selectbox("Algorithm",["Logistic Regression","Decision Tree","K-Nearest Neighbors","Gaussian Naive Bayes"])
    test=st.slider("Test split",.15,.4,.25,.05,key="clftest")
    seed=st.number_input("Random seed",0,9999,42,key="clfseed")
    stratify=y if pd.Series(y).value_counts().min()>=2 else None
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=test,random_state=int(seed),stratify=stratify)
    model=clf_pipeline(algo,int(seed)); model.fit(Xtr,ytr); pred=model.predict(Xte)
    metrics([("Accuracy",f"{accuracy_score(yte,pred):.3f}"),("Precision",f"{precision_score(yte,pred,average='weighted',zero_division=0):.3f}"),("Recall",f"{recall_score(yte,pred,average='weighted',zero_division=0):.3f}"),("F1",f"{f1_score(yte,pred,average='weighted',zero_division=0):.3f}")])
    a,b=st.columns(2)
    with a:
        fig,ax=plt.subplots(figsize=(6,5)); ConfusionMatrixDisplay.from_predictions(yte,pred,ax=ax,colorbar=False); show_fig(fig)
    with b: st.code(classification_report(yte,pred,zero_division=0))
    est=model.named_steps["model"]
    if hasattr(est,"feature_importances_"):
        imp=pd.Series(est.feature_importances_,index=X.columns).sort_values().tail(15)
        fig,ax=plt.subplots(figsize=(8,5)); imp.plot(kind="barh",ax=ax); show_fig(fig)

elif page=="Normalization & Standardization":
    st.title("Normalization & Standardization")
    df=clean_df(students)
    cols=st.multiselect("Choose numeric features",NUMERIC,default=["study_hours_daily","attendance_pct","previous_score","assignment_avg"])
    if cols:
        raw=df[cols]; mini=pd.DataFrame(MinMaxScaler().fit_transform(raw),columns=cols); standard=pd.DataFrame(StandardScaler().fit_transform(raw),columns=cols)
        t1,t2,t3=st.tabs(["Original","Min-Max","Standardized"])
        for tab,d in [(t1,raw),(t2,mini),(t3,standard)]:
            with tab:
                st.dataframe(d.describe().round(3),use_container_width=True)
                fig,ax=plt.subplots(figsize=(9,4)); sns.boxplot(data=d,ax=ax); show_fig(fig)
        st.info("Min-Max scaling maps features to [0,1]. Standardization produces approximately mean 0 and standard deviation 1. Fit scalers on training data only in production to avoid leakage.")

elif page=="09–10 · SVM Kernel Lab":
    st.title("09–10 · SVM Kernel Lab")
    source=st.selectbox("Dataset",["Synthetic moons","Synthetic circles","Student academic risk"])
    if source=="Synthetic moons":
        arr,y=make_moons(n_samples=800,noise=.23,random_state=42); X=pd.DataFrame(arr,columns=["feature_1","feature_2"])
    elif source=="Synthetic circles":
        arr,y=make_circles(n_samples=800,noise=.12,factor=.45,random_state=42); X=pd.DataFrame(arr,columns=["feature_1","feature_2"])
    else: X,y,_=get_clf_data(source)
    kernel=st.selectbox("Kernel",["linear","poly","rbf"])
    C=st.slider("C",.1,10.,1.,.1); gamma=st.selectbox("Gamma",["scale","auto",.1,1.,5.])
    test=st.slider("Test split",.15,.4,.25,.05,key="svmtest")
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=test,random_state=42,stratify=y)
    model=Pipeline([("imputer",SimpleImputer(strategy="median")),("scaler",StandardScaler()),("model",SVC(kernel=kernel,C=C,gamma=gamma,degree=3))])
    model.fit(Xtr,ytr); pred=model.predict(Xte)
    metrics([("Accuracy",f"{accuracy_score(yte,pred):.3f}"),("Precision",f"{precision_score(yte,pred,average='weighted',zero_division=0):.3f}"),("Recall",f"{recall_score(yte,pred,average='weighted',zero_division=0):.3f}"),("F1",f"{f1_score(yte,pred,average='weighted',zero_division=0):.3f}")])
    if X.shape[1]==2:
        fig,ax=plt.subplots(figsize=(7,5)); ax.scatter(X.iloc[:,0],X.iloc[:,1],c=y,cmap="viridis",s=18,alpha=.7); ax.set_title(f"{source} · {kernel} kernel"); show_fig(fig)
    st.code(classification_report(yte,pred,zero_division=0))
    st.caption("The original lab may specify UCI Banknote Authentication for Experiment 09. This combined app demonstrates linear SVM but does not bundle that exact external dataset.")

elif page=="11 · Decision Tree vs Random Forest":
    st.title("11 · Decision Tree vs Random Forest")
    st.write("Both models use the same selected features and train/test split.")
    task=st.radio("Task",["Classification","Regression"],horizontal=True)
    test=st.slider("Test set size",.15,.4,.25,.05,key="ex11test")
    seed=st.number_input("Random seed",0,9999,42,key="ex11seed")
    depth_opt=st.selectbox("Maximum tree depth",["Unlimited",3,5,8,12])
    depth=None if depth_opt=="Unlimited" else int(depth_opt)
    trees=st.slider("Random Forest estimators",50,300,160,10)
    if task=="Classification":
        source=st.selectbox("Dataset",["Student academic risk","Iris benchmark"],key="ex11source")
        X,y,_=get_clf_data(source)
        Xtr,Xte,ytr,yte,models,result=compare_classifiers(X,y,int(seed),test,depth,trees)
        st.dataframe(result.round(4),hide_index=True,use_container_width=True)
        st.bar_chart(result.set_index("Model")[["Accuracy","Precision (weighted)","Recall (weighted)","F1 (weighted)"]])
        chosen=st.selectbox("Inspect model",list(models),key="ex11clfmodel")
        pred=models[chosen].predict(Xte)
        a,b=st.columns(2)
        with a:
            fig,ax=plt.subplots(figsize=(6,5)); ConfusionMatrixDisplay.from_predictions(yte,pred,ax=ax,colorbar=False); show_fig(fig)
        with b: st.code(classification_report(yte,pred,zero_division=0))
        est=models[chosen].named_steps["model"]
        imp=pd.Series(est.feature_importances_,index=X.columns).sort_values().tail(15)
        fig,ax=plt.subplots(figsize=(8,5)); imp.plot(kind="barh",ax=ax); ax.set_title(chosen+" feature importance"); show_fig(fig)
        st.download_button("Download comparison metrics",result.to_csv(index=False).encode(),"classification_model_comparison.csv","text/csv")
    else:
        df=clean_df(students)
        target=st.selectbox("Target",["final_score","commute_minutes"])
        features=st.multiselect("Input features",NUMERIC,default=["study_hours_daily","attendance_pct","previous_score","assignment_avg"])
        if not features: features=["study_hours_daily","attendance_pct"]
        X=df[features]; y=df[target]
        Xtr,Xte,ytr,yte,models,preds,result=compare_regressors(X,y,int(seed),test,depth,trees)
        st.dataframe(result.round(4),hide_index=True,use_container_width=True)
        st.bar_chart(result.set_index("Model")[["MAE","RMSE","R²"]])
        chosen=st.selectbox("Inspect model",list(models),key="ex11regmodel")
        pred=preds[chosen]
        fig,ax=plt.subplots(figsize=(8,4)); ax.scatter(yte,pred,alpha=.7); lo=min(float(yte.min()),float(pred.min())); hi=max(float(yte.max()),float(pred.max())); ax.plot([lo,hi],[lo,hi],"--"); ax.set_xlabel("Actual"); ax.set_ylabel("Predicted"); ax.set_title(chosen+" · Actual vs predicted"); show_fig(fig)
        est=models[chosen].named_steps["model"]
        imp=pd.Series(est.feature_importances_,index=X.columns).sort_values()
        fig,ax=plt.subplots(figsize=(8,5)); imp.plot(kind="barh",ax=ax); ax.set_title(chosen+" feature importance"); show_fig(fig)
        out=pd.DataFrame({"actual":yte.to_numpy(),"decision_tree_prediction":preds["Decision Tree"],"random_forest_prediction":preds["Random Forest"]})
        st.download_button("Download predictions",out.to_csv(index=False).encode(),"regression_predictions.csv","text/csv")
    st.markdown("#### Interpretation")
    st.write("- Decision Trees are interpretable but can overfit when too deep.")
    st.write("- Random Forest averages multiple trees and often generalizes better, but it is less directly interpretable.")
    st.write("- Neither model is guaranteed to win. Evaluate the held-out metrics.")

elif page=="Student Risk Playground":
    st.title("Student Risk Playground")
    st.write("Adjust example inputs to see how a model classifies a synthetic academic-risk profile.")
    a,b,c=st.columns(3)
    with a:
        study=st.slider("Study hours/day",0.,8.,2.5,.5)
        attendance=st.slider("Attendance (%)",35,100,82)
        previous=st.slider("Previous score",15,100,68)
    with b:
        assignment=st.slider("Assignment average",10,100,78)
        sleep=st.slider("Sleep hours",3.,11.,7.,.5)
        commute=st.slider("Commute minutes",1,100,25)
    with c:
        family=st.selectbox("Family support",["Low","Medium","High"])
        internet=st.selectbox("Internet access",["No","Yes"])
        extra=st.selectbox("Extracurricular activities",["No","Yes"])
    df=clean_df(students)
    X=pd.get_dummies(df[NUMERIC+["family_support","internet_access","extracurricular"]],drop_first=True,dtype=int)
    y=df[TARGET_CLF]
    model=Pipeline([("imputer",SimpleImputer(strategy="median")),("scaler",StandardScaler()),("model",RandomForestClassifier(n_estimators=180,random_state=42,class_weight="balanced"))])
    model.fit(X,y)
    raw=pd.DataFrame([{"study_hours_daily":study,"attendance_pct":attendance,"previous_score":previous,"assignment_avg":assignment,"sleep_hours":sleep,"commute_minutes":commute,"family_support":family,"internet_access":internet,"extracurricular":extra}])
    sample=pd.get_dummies(raw,drop_first=True,dtype=int).reindex(columns=X.columns,fill_value=0)
    pred=model.predict(sample)[0]; probs=model.predict_proba(sample)[0]
    metrics([("Illustrative risk category",pred),("Top class probability",f"{max(probs):.1%}"),("Profile features",len(raw.columns))])
    st.bar_chart(pd.DataFrame({"Risk category":model.classes_,"Probability":probs}).set_index("Risk category"))
    st.warning("This is a synthetic demonstration, not a validated student assessment. Do not use it for grading, discipline, admissions, or other high-stakes decisions.")
    st.download_button("Download profile input",raw.to_csv(index=False).encode(),"student_profile.csv","text/csv")

else:
    st.title("Dataset & Project Notes")
    st.markdown("""
    ### Dataset
    The default data is generated by the app with a fixed random seed. It includes study time, attendance, prior score, assignment average, sleep, commute time, family support, internet access, extracurricular participation, synthetic final score, and a synthetic academic-risk label. Missing values are intentionally introduced for preprocessing demonstrations.

    ### Ethical use
    - Synthetic data is not representative of real students.
    - Risk labels are generated from simplified rules and do not represent a validated educational assessment.
    - Never use the dashboard to punish, rank, exclude, or make consequential decisions about individual students.
    - Real-world use requires consent, privacy safeguards, fairness evaluation, transparent limitations, and educator oversight.

    ### Experiment 11 design
    - Classification target: academic-risk category or Iris benchmark.
    - Regression target: final score or commute time.
    - Decision Tree and Random Forest share the same split, selected features and random seed.
    - Classification: accuracy, weighted precision/recall/F1, confusion matrix, classification report.
    - Regression: MAE, MSE, RMSE, R² and actual-versus-predicted plot.
    - Feature importance and downloadable metrics/predictions are included.

    ### Exact dataset caveat
    If Experiment 09 in your lab specifically requires the UCI Banknote Authentication dataset, this combined app does not bundle that external CSV. The SVM module demonstrates linear, polynomial and RBF kernels on synthetic or student-related data; use the specified banknote CSV if your instructor requires exact reproduction.
    """)
    st.subheader("Feature dictionary")
    st.dataframe(pd.DataFrame([
        ["study_hours_daily","Daily study time","Input"],
        ["attendance_pct","Attendance percentage","Input"],
        ["previous_score","Prior academic score","Input"],
        ["assignment_avg","Average assignment score","Input"],
        ["sleep_hours","Sleep hours","Input"],
        ["commute_minutes","Commute duration","Input"],
        ["family_support","Self-reported support category","Input"],
        ["internet_access","Internet access availability","Input"],
        ["extracurricular","Extracurricular participation","Input"],
        ["final_score","Synthetic final score","Regression target"],
        ["academic_risk","Synthetic academic-risk label","Classification target"],
    ],columns=["Feature","Description","Role"]),hide_index=True,use_container_width=True)
