# EduPulse — Student Performance & Academic Risk Predictor

A modern Streamlit dashboard bringing the core concepts from 11 machine-learning lab experiments into one student analytics project.

## Features and experiment mapping

- **Experiment 01 — EDA:** Pandas summaries, missing-value analysis, Matplotlib and Seaborn plots, correlations, CSV upload/download.
- **Experiments 02–03 — Regression:** Simple and multiple linear regression with MAE, MSE, RMSE, R² and actual-vs-predicted plots.
- **Experiments 04–08 — Classification:** Logistic Regression, Decision Tree, KNN and Gaussian Naive Bayes; metrics, confusion matrix and classification report.
- **Scaling practical:** Compare raw features, Min-Max normalization and standardization.
- **Experiment 09 — Linear SVM:** Linear kernel demonstration.
- **Experiment 10 — Non-linear SVM:** Polynomial and RBF kernels with adjustable C and gamma.
- **Experiment 11 — Decision Tree vs Random Forest:** Classification and regression comparisons, shared train/test split, evaluation metrics, feature importance, confusion matrix / actual-vs-predicted plots and downloadable results.
- **Student Risk Playground:** Adjustable profile inputs and illustrative academic-risk classification.

## Run locally

### macOS / Linux
```bash
cd Student_Performance_Academic_Risk_Predictor
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

### Windows PowerShell
```powershell
cd Student_Performance_Academic_Risk_Predictor
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

Open the local URL printed by Streamlit, usually `http://localhost:8501`.

## Dataset notes

The built-in dataset is generated deterministically in code and does not require a download. It contains study hours, attendance, previous score, assignment average, sleep, commute time, family support, internet access, extracurricular participation, a synthetic final score, and a synthetic risk category. Missing values are intentionally added to demonstrate cleaning.

The dashboard also includes Iris and Breast Cancer educational benchmark datasets from scikit-learn, plus CSV upload for EDA.

**Important:** The student dataset and risk labels are synthetic and not validated. Do not use this prototype to grade, rank, discipline, admit, exclude, or otherwise make high-stakes decisions about real students.

If your Experiment 09 specifically requires the UCI Banknote Authentication dataset, download that CSV separately; this combined app does not bundle that exact external dataset.

## Experiment 11 comparison design

- Classification: synthetic student risk or Iris.
- Regression: synthetic final score or commute time.
- Decision Tree and Random Forest use the same selected features, train/test split, and random seed.
- Classification metrics: accuracy, weighted precision, weighted recall, weighted F1; confusion matrix and classification report.
- Regression metrics: MAE, MSE, RMSE, R²; actual-vs-predicted plot.
- Tree-based feature importance and downloadable results are included.

## Project structure

```text
Student_Performance_Academic_Risk_Predictor/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── data/
└── models/
```

## Push to GitHub

```bash
git init
git add .
git commit -m "Build EduPulse student analytics ML dashboard"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/Student-Performance-Academic-Risk-Predictor.git
git push -u origin main
```
